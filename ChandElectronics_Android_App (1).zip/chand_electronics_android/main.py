"""
main.py - Chand Electronics (Android)
Kivy/KivyMD mobile app sharing the same SQLite schema/logic as the Windows
desktop edition. Build with Buildozer (see buildozer.spec / README.md).
"""

from kivy.core.window import Window
from kivy.metrics import dp
from kivymd.app import MDApp
from kivymd.uix.screenmanager import MDScreenManager

import db

# Convenient desktop-preview window size while developing/testing on a PC.
# Buildozer/Android ignores this and uses the real device screen.
Window.size = (400, 760)


class ChandElectronicsApp(MDApp):
    def build(self):
        self.title = "Chand Electronics"
        self.theme_cls.primary_palette = "Blue"
        self.theme_cls.accent_palette = "Amber"
        self.theme_cls.theme_style = "Light"

        db.init_db()

        from screens.login_screen import LoginScreen
        from screens.shell_screen import ShellScreen

        sm = MDScreenManager()
        sm.add_widget(LoginScreen(name="login"))
        sm.add_widget(ShellScreen(name="shell"))
        sm.current = "login"
        return sm


if __name__ == "__main__":
    ChandElectronicsApp().run()
