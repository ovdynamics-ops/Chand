"""widgets.py - small reusable KivyMD building blocks used across screens."""

from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton, MDRaisedButton
from kivymd.uix.snackbar import Snackbar

import theme


def stat_card(title, value, color=theme.PRIMARY, subtitle=None):
    card = MDCard(orientation="vertical", padding=dp(14), spacing=dp(4),
                   size_hint_y=None, height=dp(96), radius=[10], elevation=1,
                   md_bg_color=theme.hex_to_rgba(theme.CARD_BG))
    card.add_widget(MDLabel(text=title, font_style="Caption", theme_text_color="Custom",
                             text_color=theme.hex_to_rgba(theme.TEXT_MUTED), size_hint_y=None, height=dp(18)))
    card.add_widget(MDLabel(text=value, font_style="H6", bold=True, theme_text_color="Custom",
                             text_color=theme.hex_to_rgba(color), size_hint_y=None, height=dp(30)))
    if subtitle:
        card.add_widget(MDLabel(text=subtitle, font_style="Caption", theme_text_color="Custom",
                                 text_color=theme.hex_to_rgba(theme.TEXT_MUTED), size_hint_y=None, height=dp(16)))
    return card


def info_row(label, value, value_color=None):
    row = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(28))
    row.add_widget(MDLabel(text=label, theme_text_color="Custom",
                            text_color=theme.hex_to_rgba(theme.TEXT_MUTED), size_hint_x=0.5))
    row.add_widget(MDLabel(text=value, halign="right", bold=True, theme_text_color="Custom",
                            text_color=theme.hex_to_rgba(value_color or "#1B1F27"), size_hint_x=0.5))
    return row


def show_snackbar(text):
    Snackbar(text=text, duration=2.2).open()


def confirm_dialog(title, text, on_confirm, confirm_text="Confirm"):
    dialog = None

    def _confirm(*a):
        dialog.dismiss()
        on_confirm()

    def _cancel(*a):
        dialog.dismiss()

    dialog = MDDialog(
        title=title,
        text=text,
        buttons=[
            MDFlatButton(text="Cancel", on_release=_cancel),
            MDRaisedButton(text=confirm_text, md_bg_color=theme.hex_to_rgba(theme.DANGER), on_release=_confirm),
        ],
    )
    dialog.open()
    return dialog


def info_dialog(title, text, on_dismiss=None):
    dialog = None

    def _close(*a):
        dialog.dismiss()
        if on_dismiss:
            on_dismiss()

    dialog = MDDialog(title=title, text=text, buttons=[MDRaisedButton(text="OK", on_release=_close)])
    dialog.open()
    return dialog
