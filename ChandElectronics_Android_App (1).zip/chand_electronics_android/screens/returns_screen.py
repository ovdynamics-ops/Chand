"""returns_screen.py - process item returns (customer, reason, date, item)."""

from datetime import date
from kivy.metrics import dp
from kivy.uix.screenmanager import Screen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.list import MDList, ThreeLineListItem
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.dialog import MDDialog
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.selectioncontrol import MDCheckbox

import db
import theme
from widgets import show_snackbar, info_dialog

REASONS = ["Defective / Not Working", "Wrong Item Delivered", "Customer Changed Mind",
           "Damaged in Transit", "Other"]


class ReturnsScreen(Screen):
    def __init__(self, app_shell=None, **kwargs):
        super().__init__(**kwargs)
        self.app_shell = app_shell

        root = MDBoxLayout(orientation="vertical")

        top = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56), padding=(dp(12), 0),
                           spacing=dp(8))
        self.search_field = MDTextField(hint_text="Search returns...", size_hint_x=0.7)
        self.search_field.bind(text=lambda *a: self.refresh())
        top.add_widget(self.search_field)
        top.add_widget(MDIconButton(icon="plus-circle", theme_text_color="Custom",
                                     text_color=theme.hex_to_rgba(theme.DANGER),
                                     on_release=lambda *a: self.open_return_form()))
        root.add_widget(top)

        self.scroll = MDScrollView()
        self.list_widget = MDList()
        self.scroll.add_widget(self.list_widget)
        root.add_widget(self.scroll)

        self.add_widget(root)

    def refresh(self):
        self.list_widget.clear_widgets()
        for r in db.get_returns(search=self.search_field.text or None):
            secondary = f"{r['product_name']} x{r['qty']}  |  {r['reason'] or '-'}"
            tertiary = f"{r['return_date']}  |  Refund: {theme.currency(r['refund_amount'])}"
            self.list_widget.add_widget(ThreeLineListItem(
                text=f"{r['customer_name']}  ({r['invoice_no'] or 'manual'})",
                secondary_text=secondary, tertiary_text=tertiary))

    def open_return_form(self):
        ReturnFormDialog.open(self)


class ReturnFormDialog:
    @staticmethod
    def open(returns_screen):
        content = MDBoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None,
                               adaptive_height=True, padding=(0, dp(10)))

        # --- related sale (optional) ---
        sales_by_label = {"None / Manual Entry": None}
        for s in db.get_sales():
            label = f"{s['invoice_no']} - {s['customer_name'] or 'Walk-in'} ({s['sale_date']})"
            sales_by_label[label] = s["id"]

        sale_field = MDTextField(hint_text="Related Sale (optional, tap to pick)", readonly=True,
                                  text="None / Manual Entry")
        content.add_widget(sale_field)

        customer_field = MDTextField(hint_text="Customer Name *")
        content.add_widget(customer_field)

        products_by_label = {}
        for p in db.get_products():
            products_by_label[f"{p['name']} ({p['category']})"] = p
        product_field = MDTextField(hint_text="Product * (tap to pick)", readonly=True)
        content.add_widget(product_field)

        qty_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56), spacing=dp(8))
        qty_field = MDTextField(hint_text="Qty Returned *", text="1", input_filter="int")
        date_field = MDTextField(hint_text="Return Date", text=date.today().isoformat())
        qty_row.add_widget(qty_field)
        qty_row.add_widget(date_field)
        content.add_widget(qty_row)

        reason_field = MDTextField(hint_text="Reason (tap to pick)", readonly=True, text=REASONS[0])
        content.add_widget(reason_field)

        refund_field = MDTextField(hint_text="Refund / Value Given Back (Rs.)", text="0", input_filter="float")
        content.add_widget(refund_field)

        restock_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(44), spacing=dp(8))
        restock_check = MDCheckbox(size_hint_x=None, width=dp(40), active=True)
        restock_row.add_widget(restock_check)
        restock_row.add_widget(MDLabel(text="Add item back to stock"))
        content.add_widget(restock_row)

        selected_product = {"value": None}
        selected_sale = {"value": None}

        def open_sale_menu(*a):
            items = [{"text": lbl, "viewclass": "OneLineListItem",
                      "on_release": lambda lbl=lbl: pick_sale(lbl)} for lbl in sales_by_label.keys()]
            menu = MDDropdownMenu(caller=sale_field, items=items, width_mult=4, max_height=dp(300))
            menu.open()
            sale_field._menu = menu

        def pick_sale(label):
            sale_field.text = label
            sale_field._menu.dismiss()
            selected_sale["value"] = sales_by_label.get(label)
            if selected_sale["value"]:
                sale = db.get_sale(selected_sale["value"])
                if sale and sale["customer_name"]:
                    customer_field.text = sale["customer_name"]
                items = db.get_sale_items(selected_sale["value"])
                if items:
                    it = items[0]
                    match = next((lbl for lbl, p in products_by_label.items()
                                  if p["name"] == it["product_name"]), None)
                    if match:
                        product_field.text = match
                        selected_product["value"] = products_by_label[match]
                    qty_field.text = str(it["qty"])
                    refund_field.text = str(it["total_price"])

        def open_product_menu(*a):
            items = [{"text": lbl, "viewclass": "OneLineListItem",
                      "on_release": lambda lbl=lbl: pick_product(lbl)} for lbl in products_by_label.keys()]
            menu = MDDropdownMenu(caller=product_field, items=items, width_mult=4, max_height=dp(300))
            menu.open()
            product_field._menu = menu

        def pick_product(label):
            product_field.text = label
            product_field._menu.dismiss()
            selected_product["value"] = products_by_label.get(label)

        def open_reason_menu(*a):
            items = [{"text": r, "viewclass": "OneLineListItem",
                      "on_release": lambda r=r: pick_reason(r)} for r in REASONS]
            menu = MDDropdownMenu(caller=reason_field, items=items, width_mult=4, max_height=dp(250))
            menu.open()
            reason_field._menu = menu

        def pick_reason(r):
            reason_field.text = r
            reason_field._menu.dismiss()

        sale_field.bind(focus=lambda inst, val: open_sale_menu() if val else None)
        product_field.bind(focus=lambda inst, val: open_product_menu() if val else None)
        reason_field.bind(focus=lambda inst, val: open_reason_menu() if val else None)

        dialog = None

        def do_save(*a):
            customer = customer_field.text.strip()
            product = selected_product["value"]
            rdate = date_field.text.strip()
            reason = reason_field.text.strip()

            if not customer:
                show_snackbar("Customer name is required.")
                return
            if not product:
                show_snackbar("Please select the returned product.")
                return
            if not rdate:
                show_snackbar("Return date is required.")
                return
            try:
                qty = int(qty_field.text)
                if qty <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                show_snackbar("Enter a valid positive quantity.")
                return
            try:
                refund = float(refund_field.text or 0)
            except ValueError:
                show_snackbar("Refund amount must be numeric.")
                return

            db.process_return(rdate, customer, product["id"], product["name"], qty, reason, refund,
                               sale_id=selected_sale["value"], restock=restock_check.active)
            show_snackbar(f"Return recorded for {customer} - {product['name']} x{qty}")
            dialog.dismiss()
            returns_screen.refresh()
            if returns_screen.app_shell:
                returns_screen.app_shell.refresh_all()

        scroll = MDScrollView(size_hint_y=None, height=dp(440))
        scroll.add_widget(content)

        dialog = MDDialog(title="Process Return", type="custom", content_cls=scroll,
                           buttons=[MDFlatButton(text="Cancel", on_release=lambda *a: dialog.dismiss()),
                                    MDRaisedButton(text="Process Return",
                                                   md_bg_color=theme.hex_to_rgba(theme.DANGER),
                                                   on_release=do_save)])
        dialog.open()
