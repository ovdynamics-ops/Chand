"""accounts_screen.py - accounts ledger view + manual expense entry."""

from datetime import date
from kivy.metrics import dp
from kivy.uix.screenmanager import Screen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.gridlayout import MDGridLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.list import MDList, TwoLineListItem
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.dialog import MDDialog
from kivymd.uix.menu import MDDropdownMenu

import db
import theme
from widgets import show_snackbar, stat_card

EXPENSE_CATEGORIES = ["Rent", "Utilities (Electricity/Gas)", "Salary/Wages", "Transport",
                       "Maintenance", "Marketing", "Purchase", "Misc"]


class AccountsScreen(Screen):
    def __init__(self, app_shell=None, **kwargs):
        super().__init__(**kwargs)
        self.app_shell = app_shell

        root = MDBoxLayout(orientation="vertical")

        top = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56), padding=(dp(12), 0))
        top.add_widget(MDLabel(text="Accounts", bold=True, font_style="H6"))
        top.add_widget(MDIconButton(icon="cash-minus", theme_text_color="Custom",
                                     text_color=theme.hex_to_rgba(theme.DANGER),
                                     on_release=lambda *a: self.open_expense_form()))
        root.add_widget(top)

        self.scroll = MDScrollView()
        self.content = MDBoxLayout(orientation="vertical", padding=dp(14), spacing=dp(10),
                                    size_hint_y=None, adaptive_height=True)
        self.scroll.add_widget(self.content)
        root.add_widget(self.scroll)

        self.stats_grid = MDGridLayout(cols=1, spacing=dp(10), size_hint_y=None, adaptive_height=True)
        self.content.add_widget(self.stats_grid)

        self.content.add_widget(MDLabel(text="Ledger", bold=True, font_style="Subtitle1",
                                         size_hint_y=None, height=dp(30)))
        self.ledger_list = MDList()
        self.content.add_widget(self.ledger_list)

        self.add_widget(root)

    def refresh(self):
        self.stats_grid.clear_widgets()
        income, expense, balance = db.ledger_totals()
        for title, value, color in [("Total Income", theme.currency(income), theme.SUCCESS),
                                     ("Total Expense", theme.currency(expense), theme.DANGER),
                                     ("Net Balance", theme.currency(balance), theme.PRIMARY)]:
            self.stats_grid.add_widget(stat_card(title, value, color))

        self.ledger_list.clear_widgets()
        for e in db.get_ledger_entries()[:60]:
            color = theme.SUCCESS if e["entry_type"] == "Income" else theme.DANGER
            item = TwoLineListItem(text=f"{e['category']} - {theme.currency(e['amount'])}",
                                    secondary_text=f"{e['entry_date']}  |  {e['description'] or ''}")
            item.secondary_theme_text_color = "Custom"
            self.ledger_list.add_widget(item)

    def open_expense_form(self):
        content = MDBoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None,
                               adaptive_height=True, padding=(0, dp(10)))
        date_field = MDTextField(hint_text="Date (YYYY-MM-DD)", text=date.today().isoformat())
        category_field = MDTextField(hint_text="Category (tap to pick)", readonly=True,
                                      text=EXPENSE_CATEGORIES[0])
        desc_field = MDTextField(hint_text="Description")
        amount_field = MDTextField(hint_text="Amount (Rs.) *", input_filter="float")
        for f in [date_field, category_field, desc_field, amount_field]:
            content.add_widget(f)

        def open_cat_menu(*a):
            items = [{"text": c, "viewclass": "OneLineListItem",
                      "on_release": lambda c=c: pick_cat(c)} for c in EXPENSE_CATEGORIES]
            menu = MDDropdownMenu(caller=category_field, items=items, width_mult=4, max_height=dp(300))
            menu.open()
            category_field._menu = menu

        def pick_cat(c):
            category_field.text = c
            category_field._menu.dismiss()

        category_field.bind(focus=lambda inst, val: open_cat_menu() if val else None)

        dialog = None

        def do_save(*a):
            d = date_field.text.strip()
            cat = category_field.text.strip()
            try:
                amount = float(amount_field.text)
                if amount <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                show_snackbar("Enter a valid positive amount.")
                return
            if not d or not cat:
                show_snackbar("Date and category are required.")
                return
            db.add_ledger_entry(d, "Expense", cat, desc_field.text.strip(), amount, "manual")
            show_snackbar("Expense recorded.")
            dialog.dismiss()
            self.refresh()

        dialog = MDDialog(title="Add Expense", type="custom", content_cls=content,
                           buttons=[MDFlatButton(text="Cancel", on_release=lambda *a: dialog.dismiss()),
                                    MDRaisedButton(text="Save Expense",
                                                   md_bg_color=theme.hex_to_rgba(theme.DANGER),
                                                   on_release=do_save)])
        dialog.open()
