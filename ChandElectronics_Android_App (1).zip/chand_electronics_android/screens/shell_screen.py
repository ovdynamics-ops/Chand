"""shell_screen.py - post-login shell: top app bar + navigation drawer + module screens."""

from kivy.metrics import dp
from kivy.uix.screenmanager import Screen, NoTransition
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.toolbar import MDTopAppBar
from kivymd.uix.navigationdrawer import MDNavigationDrawer, MDNavigationLayout
from kivymd.uix.list import MDList, OneLineIconListItem, IconLeftWidget
from kivymd.uix.screenmanager import MDScreenManager

import theme


MENU_ITEMS = [
    ("Dashboard", "view-dashboard", "dashboard"),
    ("Inventory", "fridge", "inventory"),
    ("Customers", "account-group", "customers"),
    ("Sales", "cart", "sales"),
    ("Installments", "calendar-clock", "installments"),
    ("Returns", "keyboard-return", "returns"),
    ("Accounts", "cash-multiple", "accounts"),
]


class ShellScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._built = False

    def on_login(self):
        if self._built:
            self.inner_sm.get_screen("dashboard").refresh()
            return
        self._built = True
        self.build()

    def build(self):
        root = MDBoxLayout(orientation="vertical")

        self.toolbar = MDTopAppBar(title="Chand Electronics", elevation=4,
                                    md_bg_color=theme.hex_to_rgba(theme.PRIMARY),
                                    left_action_items=[["menu", lambda x: self.nav_drawer.set_state("open")]],
                                    right_action_items=[["logout", lambda x: self.logout()]])
        root.add_widget(self.toolbar)

        nav_layout = MDNavigationLayout()

        self.inner_sm = MDScreenManager(transition=NoTransition())
        self._add_screens()

        self.nav_drawer = MDNavigationDrawer()
        drawer_box = MDBoxLayout(orientation="vertical")
        drawer_list = MDList()
        for label, icon, screen_name in MENU_ITEMS:
            item = OneLineIconListItem(text=label, on_release=self._make_nav_handler(screen_name))
            item.add_widget(IconLeftWidget(icon=icon))
            drawer_list.add_widget(item)
        drawer_box.add_widget(drawer_list)
        self.nav_drawer.add_widget(drawer_box)

        nav_layout.add_widget(self.inner_sm)
        nav_layout.add_widget(self.nav_drawer)
        root.add_widget(nav_layout)

        self.add_widget(root)
        self.inner_sm.current = "dashboard"

    def _add_screens(self):
        from screens.dashboard_screen import DashboardScreen
        from screens.inventory_screen import InventoryScreen
        from screens.customers_screen import CustomersScreen
        from screens.sales_screen import SalesScreen
        from screens.installments_screen import InstallmentsScreen
        from screens.returns_screen import ReturnsScreen
        from screens.accounts_screen import AccountsScreen

        self.inner_sm.add_widget(DashboardScreen(name="dashboard", app_shell=self))
        self.inner_sm.add_widget(InventoryScreen(name="inventory", app_shell=self))
        self.inner_sm.add_widget(CustomersScreen(name="customers", app_shell=self))
        self.inner_sm.add_widget(SalesScreen(name="sales", app_shell=self))
        self.inner_sm.add_widget(InstallmentsScreen(name="installments", app_shell=self))
        self.inner_sm.add_widget(ReturnsScreen(name="returns", app_shell=self))
        self.inner_sm.add_widget(AccountsScreen(name="accounts", app_shell=self))

    def _make_nav_handler(self, screen_name):
        def handler(*a):
            self.nav_drawer.set_state("close")
            self.go_to(screen_name)
        return handler

    def go_to(self, screen_name):
        self.inner_sm.current = screen_name
        screen = self.inner_sm.get_screen(screen_name)
        if hasattr(screen, "refresh"):
            screen.refresh()
        titles = {name: label for label, icon, name in MENU_ITEMS}
        self.toolbar.title = titles.get(screen_name, "Chand Electronics")

    def refresh_all(self):
        for _, _, screen_name in MENU_ITEMS:
            screen = self.inner_sm.get_screen(screen_name)
            if hasattr(screen, "refresh"):
                screen.refresh()

    def logout(self):
        self.manager.current = "login"
