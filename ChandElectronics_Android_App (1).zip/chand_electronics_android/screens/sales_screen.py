"""sales_screen.py - build a cart, checkout as Cash or Installment (with profit
margin: flat % or variable per-item %), and browse sales history."""

from kivy.metrics import dp
from kivy.uix.screenmanager import Screen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.list import MDList, OneLineListItem, TwoLineListItem, IconRightWidget, TwoLineRightIconListItem
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog
from kivymd.uix.selectioncontrol import MDCheckbox

import db
import theme
from widgets import show_snackbar, info_dialog


class PickerField(MDBoxLayout):
    """A tap-to-open dropdown selector built from an MDTextField + MDDropdownMenu."""

    def __init__(self, hint_text, on_select=None, **kwargs):
        super().__init__(orientation="vertical", size_hint_y=None, height=dp(56), **kwargs)
        self.on_select_cb = on_select
        self.field = MDTextField(hint_text=hint_text, readonly=True)
        self.field.bind(focus=self._on_focus)
        self.add_widget(self.field)
        self.menu = None
        self.items_map = {}

    def set_options(self, labels_to_values):
        self.items_map = labels_to_values

    def _on_focus(self, instance, focused):
        if focused:
            self.open_menu()

    def open_menu(self, *a):
        menu_items = [
            {"text": label, "viewclass": "OneLineListItem",
             "on_release": lambda lbl=label: self._select(lbl)}
            for label in self.items_map.keys()
        ]
        self.menu = MDDropdownMenu(caller=self.field, items=menu_items, width_mult=4, max_height=dp(300))
        self.menu.open()

    def _select(self, label):
        self.field.text = label
        if self.menu:
            self.menu.dismiss()
        if self.on_select_cb:
            self.on_select_cb(label, self.items_map.get(label))


class SalesScreen(Screen):
    def __init__(self, app_shell=None, **kwargs):
        super().__init__(**kwargs)
        self.app_shell = app_shell
        self.cart = []
        self.products_by_label = {}
        self.customers_by_label = {}
        self.sale_type = "Cash"
        self.profit_mode = "none"

        root = MDBoxLayout(orientation="vertical")

        tabs_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(48), padding=(dp(8), dp(4)),
                                spacing=dp(6))
        self.new_sale_tab_btn = MDFlatButton(text="NEW SALE", on_release=lambda *a: self.show_view("new"))
        self.history_tab_btn = MDFlatButton(text="HISTORY", on_release=lambda *a: self.show_view("history"))
        tabs_row.add_widget(self.new_sale_tab_btn)
        tabs_row.add_widget(self.history_tab_btn)
        root.add_widget(tabs_row)

        self.view_container = MDBoxLayout(orientation="vertical")
        root.add_widget(self.view_container)

        self._build_new_sale_view()
        self._build_history_view()
        self.show_view("new")

        self.add_widget(root)

    # ------------------------------------------------------------------
    def show_view(self, which):
        self.view_container.clear_widgets()
        if which == "new":
            self.view_container.add_widget(self.new_sale_scroll)
        else:
            self.view_container.add_widget(self.history_box)
            self.refresh_history()

    def refresh(self):
        self.refresh_products()
        self.refresh_customers()
        self.refresh_history()

    # ------------------------------------------------------------------
    # NEW SALE VIEW
    # ------------------------------------------------------------------
    def _build_new_sale_view(self):
        self.new_sale_scroll = MDScrollView()
        content = MDBoxLayout(orientation="vertical", padding=dp(14), spacing=dp(10),
                               size_hint_y=None, adaptive_height=True)
        self.new_sale_scroll.add_widget(content)

        content.add_widget(MDLabel(text="Customer", bold=True, size_hint_y=None, height=dp(24)))
        self.customer_picker = PickerField(hint_text="Select customer (or Walk-in)")
        content.add_widget(self.customer_picker)

        content.add_widget(MDLabel(text="Add Product", bold=True, size_hint_y=None, height=dp(24)))
        self.product_picker = PickerField(hint_text="Select product", on_select=self._on_product_selected)
        content.add_widget(self.product_picker)

        qty_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56), spacing=dp(8))
        self.qty_field = MDTextField(hint_text="Qty", text="1", input_filter="int")
        self.price_field = MDTextField(hint_text="Unit Price (Rs.)", input_filter="float")
        qty_row.add_widget(self.qty_field)
        qty_row.add_widget(self.price_field)
        content.add_widget(qty_row)

        add_cart_btn = MDRaisedButton(text="+ ADD TO CART", size_hint_x=1,
                                       md_bg_color=theme.hex_to_rgba(theme.PRIMARY),
                                       on_release=lambda *a: self.add_to_cart())
        content.add_widget(add_cart_btn)

        content.add_widget(MDLabel(text="Cart", bold=True, size_hint_y=None, height=dp(24)))
        self.cart_list = MDList()
        content.add_widget(self.cart_list)

        discount_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56), spacing=dp(8))
        self.discount_field = MDTextField(hint_text="Discount (Rs.)", text="0", input_filter="float")
        self.discount_field.bind(text=lambda *a: self.update_totals())
        discount_row.add_widget(self.discount_field)
        content.add_widget(discount_row)

        self.totals_card = MDCard(orientation="vertical", padding=dp(12), spacing=dp(4),
                                   size_hint_y=None, height=dp(70), radius=[8],
                                   md_bg_color=theme.hex_to_rgba(theme.CARD_BG))
        self.gross_label = MDLabel(text="Gross: Rs. 0", size_hint_y=None, height=dp(24))
        self.net_label = MDLabel(text="Net: Rs. 0", bold=True, theme_text_color="Custom",
                                  text_color=theme.hex_to_rgba(theme.PRIMARY), size_hint_y=None, height=dp(28))
        self.totals_card.add_widget(self.gross_label)
        self.totals_card.add_widget(self.net_label)
        content.add_widget(self.totals_card)

        # Sale type toggle
        content.add_widget(MDLabel(text="Sale Type", bold=True, size_hint_y=None, height=dp(24)))
        type_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(44), spacing=dp(8))
        self.cash_btn = MDRaisedButton(text="CASH", md_bg_color=theme.hex_to_rgba(theme.PRIMARY),
                                        on_release=lambda *a: self.set_sale_type("Cash"))
        self.installment_btn = MDFlatButton(text="INSTALLMENT",
                                             on_release=lambda *a: self.set_sale_type("Installment"))
        type_row.add_widget(self.cash_btn)
        type_row.add_widget(self.installment_btn)
        content.add_widget(type_row)

        # Installment section (shown/hidden)
        self.installment_box = MDBoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None,
                                            adaptive_height=True)
        adv_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56), spacing=dp(8))
        self.advance_field = MDTextField(hint_text="Advance Payment (Rs.)", text="0", input_filter="float")
        self.advance_field.bind(text=lambda *a: self.update_totals())
        self.months_field = MDTextField(hint_text="Number of Months", text="12", input_filter="int")
        self.months_field.bind(text=lambda *a: self.update_totals())
        adv_row.add_widget(self.advance_field)
        adv_row.add_widget(self.months_field)
        self.installment_box.add_widget(adv_row)

        self.installment_box.add_widget(MDLabel(text="Installment Profit Margin", bold=True,
                                                  size_hint_y=None, height=dp(24)))
        self.installment_box.add_widget(MDLabel(
            text="Installment price is usually higher than cash price.", font_style="Caption",
            theme_text_color="Custom", text_color=theme.hex_to_rgba(theme.TEXT_MUTED),
            size_hint_y=None, height=dp(18)))

        profit_mode_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(44), spacing=dp(6))
        self.pm_none_btn = MDFlatButton(text="NONE", on_release=lambda *a: self.set_profit_mode("none"))
        self.pm_flat_btn = MDFlatButton(text="FLAT %", on_release=lambda *a: self.set_profit_mode("flat"))
        self.pm_item_btn = MDFlatButton(text="PER ITEM %", on_release=lambda *a: self.set_profit_mode("per_item"))
        profit_mode_row.add_widget(self.pm_none_btn)
        profit_mode_row.add_widget(self.pm_flat_btn)
        profit_mode_row.add_widget(self.pm_item_btn)
        self.installment_box.add_widget(profit_mode_row)

        self.flat_profit_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56))
        self.profit_percent_field = MDTextField(hint_text="Profit % (default 35)", text="35",
                                                  input_filter="float")
        self.profit_percent_field.bind(text=lambda *a: self.update_totals())
        self.flat_profit_row.add_widget(self.profit_percent_field)
        self.installment_box.add_widget(self.flat_profit_row)

        self.per_item_profit_btn = MDRaisedButton(text="SET PROFIT % PER ITEM", size_hint_x=1,
                                                    md_bg_color=theme.hex_to_rgba(theme.ACCENT),
                                                    on_release=lambda *a: self.open_item_profit_dialog())
        self.installment_box.add_widget(self.per_item_profit_btn)

        self.plan_card = MDCard(orientation="vertical", padding=dp(12), spacing=dp(2),
                                 size_hint_y=None, height=dp(150), radius=[8],
                                 md_bg_color=theme.hex_to_rgba("#EFF4FF"))
        self.plan_label = MDLabel(text="", theme_text_color="Custom",
                                   text_color=theme.hex_to_rgba(theme.PRIMARY_DARK), font_style="Caption")
        self.plan_card.add_widget(self.plan_label)
        self.installment_box.add_widget(self.plan_card)

        content.add_widget(self.installment_box)
        self._update_profit_visibility()

        confirm_btn = MDRaisedButton(text="✓ CONFIRM SALE", size_hint_x=1, size_hint_y=None, height=dp(50),
                                      md_bg_color=theme.hex_to_rgba(theme.SUCCESS),
                                      on_release=lambda *a: self.confirm_sale())
        content.add_widget(confirm_btn)
        clear_btn = MDFlatButton(text="CLEAR CART", size_hint_x=1, on_release=lambda *a: self.clear_cart())
        content.add_widget(clear_btn)
        content.add_widget(MDLabel(text="", size_hint_y=None, height=dp(30)))

        self.installment_box.opacity = 0
        self.installment_box.disabled = True
        self.installment_box.size_hint_y = None
        self.installment_box.height = 0

    # ------------------------------------------------------------------
    def refresh_products(self):
        products = db.get_products()
        self.products_by_label = {}
        for p in products:
            label = f"{p['name']} ({p['category']}) - Stock: {p['stock_qty']}"
            self.products_by_label[label] = p
        self.product_picker.set_options(self.products_by_label)

    def refresh_customers(self):
        customers = db.get_customers()
        self.customers_by_label = {"Walk-in Customer": None}
        for c in customers:
            label = f"{c['name']} ({c['phone'] or 'no phone'})"
            self.customers_by_label[label] = c["id"]
        self.customer_picker.set_options(self.customers_by_label)
        if not self.customer_picker.field.text:
            self.customer_picker.field.text = "Walk-in Customer"

    def _on_product_selected(self, label, product):
        if product:
            self.price_field.text = str(product["sale_price"])

    # ------------------------------------------------------------------
    def add_to_cart(self):
        label = self.product_picker.field.text
        p = self.products_by_label.get(label)
        if not p:
            show_snackbar("Please select a product.")
            return
        try:
            qty = int(self.qty_field.text)
            price = float(self.price_field.text)
            if qty <= 0 or price < 0:
                raise ValueError
        except (ValueError, TypeError):
            show_snackbar("Enter a valid quantity and price.")
            return

        already = sum(i["qty"] for i in self.cart if i["product_id"] == p["id"])
        if qty + already > p["stock_qty"]:
            show_snackbar(f"Only {p['stock_qty']} in stock (already {already} in cart).")
            return

        for item in self.cart:
            if item["product_id"] == p["id"] and item["unit_price"] == price:
                item["qty"] += qty
                self.refresh_cart_view()
                return

        self.cart.append({"product_id": p["id"], "product_name": p["name"], "qty": qty,
                           "unit_price": price, "profit_percent": 35})
        self.refresh_cart_view()

    def refresh_cart_view(self):
        self.cart_list.clear_widgets()
        show_profit = (self.sale_type == "Installment" and self.profit_mode == "per_item")
        for idx, item in enumerate(self.cart):
            total = item["qty"] * item["unit_price"]
            secondary = f"Qty {item['qty']} x {theme.currency(item['unit_price'])} = {theme.currency(total)}"
            if show_profit:
                secondary += f"  |  Profit: {item.get('profit_percent', 0):g}%"
            row = TwoLineRightIconListItem(text=item["product_name"], secondary_text=secondary)
            remove_icon = IconRightWidget(icon="close", theme_text_color="Custom",
                                           text_color=theme.hex_to_rgba(theme.DANGER))
            remove_icon.bind(on_release=self._make_remove_handler(idx))
            row.add_widget(remove_icon)
            self.cart_list.add_widget(row)
        self.update_totals()

    def _make_remove_handler(self, idx):
        def handler(*a):
            del self.cart[idx]
            self.refresh_cart_view()
        return handler

    def clear_cart(self):
        self.cart = []
        self.discount_field.text = "0"
        self.advance_field.text = "0"
        self.set_profit_mode("none")
        self.refresh_cart_view()

    def gross_total(self):
        return sum(i["qty"] * i["unit_price"] for i in self.cart)

    def get_discount(self):
        try:
            return float(self.discount_field.text or 0)
        except ValueError:
            return 0

    # ------------------------------------------------------------------
    def set_sale_type(self, sale_type):
        self.sale_type = sale_type
        if sale_type == "Cash":
            self.installment_box.opacity = 0
            self.installment_box.disabled = True
            self.installment_box.height = 0
        else:
            self.installment_box.opacity = 1
            self.installment_box.disabled = False
            self.installment_box.height = self.installment_box.minimum_height
        self.refresh_cart_view()
        self.update_totals()

    def set_profit_mode(self, mode):
        self.profit_mode = mode
        self._update_profit_visibility()
        self.refresh_cart_view()
        self.update_totals()

    def _update_profit_visibility(self):
        if self.profit_mode == "flat":
            self.flat_profit_row.opacity = 1
            self.flat_profit_row.disabled = False
            self.flat_profit_row.height = dp(56)
            self.per_item_profit_btn.opacity = 0
            self.per_item_profit_btn.disabled = True
            self.per_item_profit_btn.height = 0
        elif self.profit_mode == "per_item":
            self.flat_profit_row.opacity = 0
            self.flat_profit_row.disabled = True
            self.flat_profit_row.height = 0
            self.per_item_profit_btn.opacity = 1
            self.per_item_profit_btn.disabled = False
            self.per_item_profit_btn.height = dp(44)
        else:
            self.flat_profit_row.opacity = 0
            self.flat_profit_row.disabled = True
            self.flat_profit_row.height = 0
            self.per_item_profit_btn.opacity = 0
            self.per_item_profit_btn.disabled = True
            self.per_item_profit_btn.height = 0

    def compute_installment_base_price(self, net, discount):
        if self.profit_mode == "flat":
            try:
                pct = float(self.profit_percent_field.text or 0)
            except ValueError:
                pct = 0
            base = net * (1 + pct / 100)
            return base, base - net
        elif self.profit_mode == "per_item":
            total_with_profit = sum(
                i["qty"] * i["unit_price"] * (1 + (i.get("profit_percent") or 0) / 100) for i in self.cart)
            base = max(total_with_profit - discount, 0)
            return base, base - net
        return net, 0

    def open_item_profit_dialog(self):
        if not self.cart:
            show_snackbar("Add items to the cart first.")
            return

        content = MDBoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None,
                               adaptive_height=True, padding=(0, dp(10)))
        fields = []
        for item in self.cart:
            row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56), spacing=dp(8))
            row.add_widget(MDLabel(text=f"{item['product_name']}", size_hint_x=0.6))
            f = MDTextField(hint_text="%", text=str(item.get("profit_percent", 35)),
                             input_filter="float", size_hint_x=0.4)
            fields.append(f)
            row.add_widget(f)
            content.add_widget(row)

        dialog = None

        def do_save(*a):
            for item, f in zip(self.cart, fields):
                try:
                    item["profit_percent"] = float(f.text or 0)
                except ValueError:
                    item["profit_percent"] = 0
            self.refresh_cart_view()
            dialog.dismiss()

        dialog = MDDialog(title="Profit % per Item", type="custom", content_cls=content,
                           buttons=[MDFlatButton(text="Cancel", on_release=lambda *a: dialog.dismiss()),
                                    MDRaisedButton(text="Save", md_bg_color=theme.hex_to_rgba(theme.PRIMARY),
                                                   on_release=do_save)])
        dialog.open()

    def update_totals(self):
        gross = self.gross_total()
        discount = self.get_discount()
        net = max(gross - discount, 0)
        self.gross_label.text = f"Gross: {theme.currency(gross)}"
        self.net_label.text = f"Net: {theme.currency(net)}"

        if self.sale_type == "Installment":
            try:
                advance = float(self.advance_field.text or 0)
            except ValueError:
                advance = 0
            try:
                months = max(int(self.months_field.text or 12), 1)
            except ValueError:
                months = 12
            base_price, profit_amount = self.compute_installment_base_price(net, discount)
            financed = max(base_price - advance, 0)
            monthly = financed / months if months else 0
            profit_line = f"Profit Markup: {theme.currency(profit_amount)}\n" if profit_amount else ""
            self.plan_label.text = (
                f"Cash-Equivalent Net: {theme.currency(net)}\n"
                f"{profit_line}"
                f"Installment Price: {theme.currency(base_price)}\n"
                f"Advance Payment: {theme.currency(advance)}\n"
                f"Financed Amount: {theme.currency(financed)}\n"
                f"Monthly x{months}: {theme.currency(monthly)}"
            )

    # ------------------------------------------------------------------
    def confirm_sale(self):
        if not self.cart:
            show_snackbar("Add at least one product to the cart.")
            return

        customer_label = self.customer_picker.field.text or "Walk-in Customer"
        customer_id = self.customers_by_label.get(customer_label)
        discount = self.get_discount()
        net = max(self.gross_total() - discount, 0)

        for item in self.cart:
            p = db.get_product(item["product_id"])
            if item["qty"] > p["stock_qty"]:
                show_snackbar(f"Not enough stock for {p['name']}. Available: {p['stock_qty']}")
                return

        if self.sale_type == "Cash":
            sale_id, invoice_no, net_amt = db.finalize_cash_sale(customer_id, self.cart, discount)
            info_dialog("Sale Completed", f"Cash sale completed.\nInvoice: {invoice_no}\n"
                                           f"Amount: {theme.currency(net_amt)}")
        else:
            if customer_id is None:
                show_snackbar("Please select a registered customer for an installment sale.")
                return
            try:
                advance = float(self.advance_field.text or 0)
                months = int(self.months_field.text or 12)
            except ValueError:
                show_snackbar("Advance and months must be numeric.")
                return
            if months <= 0:
                show_snackbar("Number of months must be at least 1.")
                return

            profit_mode = None if self.profit_mode == "none" else self.profit_mode
            profit_percent = None
            if profit_mode == "flat":
                try:
                    profit_percent = float(self.profit_percent_field.text or 0)
                except ValueError:
                    profit_percent = 0

            base_price, _ = self.compute_installment_base_price(net, discount)
            if advance < 0 or advance > base_price:
                show_snackbar("Advance must be between 0 and the installment price.")
                return

            sale_id, invoice_no, installment_id = db.finalize_installment_sale(
                customer_id, self.cart, discount, advance, months,
                profit_mode=profit_mode, profit_percent=profit_percent)
            financed = max(base_price - advance, 0)
            monthly = round(financed / months, 2) if months else 0
            info_dialog("Installment Sale Completed",
                        f"Invoice: {invoice_no}\nAdvance: {theme.currency(advance)}\n"
                        f"{months} monthly installments of {theme.currency(monthly)} scheduled.\n"
                        f"See the Installments screen for the full plan.")

        self.clear_cart()
        if self.app_shell:
            self.app_shell.refresh_all()

    # ------------------------------------------------------------------
    # HISTORY VIEW
    # ------------------------------------------------------------------
    def _build_history_view(self):
        self.history_box = MDBoxLayout(orientation="vertical")
        filt_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(44),
                                padding=(dp(8), 0), spacing=dp(6))
        self.hist_filter = "All"
        for label in ["All", "Cash", "Installment"]:
            btn = MDFlatButton(text=label, on_release=self._make_hist_filter_handler(label))
            filt_row.add_widget(btn)
        self.history_box.add_widget(filt_row)

        scroll = MDScrollView()
        self.history_list = MDList()
        scroll.add_widget(self.history_list)
        self.history_box.add_widget(scroll)

    def _make_hist_filter_handler(self, label):
        def handler(*a):
            self.hist_filter = label
            self.refresh_history()
        return handler

    def refresh_history(self):
        if not hasattr(self, "history_list"):
            return
        self.history_list.clear_widgets()
        for s in db.get_sales(sale_type=self.hist_filter):
            secondary = (f"{s['sale_type']} - {theme.currency(s['net_amount'])} "
                         f"({s['customer_name'] or 'Walk-in'}) - {s['sale_date']}")
            item = TwoLineListItem(text=s["invoice_no"], secondary_text=secondary,
                                    on_release=self._make_view_items_handler(s["id"]))
            self.history_list.add_widget(item)

    def _make_view_items_handler(self, sale_id):
        def handler(*a):
            items = db.get_sale_items(sale_id)
            lines = [f"{it['product_name']} x{it['qty']} = {theme.currency(it['total_price'])}"
                     for it in items]
            info_dialog("Sale Items", "\n".join(lines) if lines else "No items.")
        return handler
