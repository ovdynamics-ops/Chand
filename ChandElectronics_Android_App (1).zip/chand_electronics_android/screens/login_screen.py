"""login_screen.py - single-admin password login."""

from kivy.metrics import dp
from kivy.uix.screenmanager import Screen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.textfield import MDTextField

import db
import theme


class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        root = MDBoxLayout(orientation="vertical", md_bg_color=theme.hex_to_rgba(theme.BG))

        header = MDBoxLayout(orientation="vertical", size_hint_y=None, height=dp(220),
                              md_bg_color=theme.hex_to_rgba(theme.PRIMARY), padding=dp(20), spacing=dp(4))
        header.add_widget(MDLabel(text="", size_hint_y=None, height=dp(20)))
        header.add_widget(MDLabel(text="⚡", halign="center", font_style="H3",
                                   theme_text_color="Custom", text_color=[1, 1, 1, 1],
                                   size_hint_y=None, height=dp(60)))
        header.add_widget(MDLabel(text="Chand Electronics", halign="center", font_style="H5", bold=True,
                                   theme_text_color="Custom", text_color=[1, 1, 1, 1],
                                   size_hint_y=None, height=dp(36)))
        header.add_widget(MDLabel(text="Shop Management - Mobile", halign="center", font_style="Caption",
                                   theme_text_color="Custom", text_color=[0.85, 0.9, 1, 1],
                                   size_hint_y=None, height=dp(20)))
        root.add_widget(header)

        body = MDBoxLayout(orientation="vertical", padding=dp(30), spacing=dp(16))
        self.pwd_field = MDTextField(hint_text="Admin Password", password=True, size_hint_y=None, height=dp(48))
        self.pwd_field.bind(on_text_validate=lambda *a: self.try_login())
        body.add_widget(self.pwd_field)

        self.error_label = MDLabel(text="", theme_text_color="Custom", text_color=theme.hex_to_rgba(theme.DANGER),
                                    font_style="Caption", size_hint_y=None, height=dp(20))
        body.add_widget(self.error_label)

        login_btn = MDRaisedButton(text="LOGIN", size_hint_x=1, size_hint_y=None, height=dp(48),
                                    md_bg_color=theme.hex_to_rgba(theme.PRIMARY),
                                    on_release=lambda *a: self.try_login())
        body.add_widget(login_btn)

        body.add_widget(MDLabel(text="Default password: admin123", halign="center", font_style="Caption",
                                 theme_text_color="Custom", text_color=theme.hex_to_rgba(theme.TEXT_MUTED),
                                 size_hint_y=None, height=dp(60)))
        root.add_widget(body)
        self.add_widget(root)

    def try_login(self):
        if db.check_password(self.pwd_field.text):
            self.error_label.text = ""
            self.pwd_field.text = ""
            shell = self.manager.get_screen("shell")
            shell.on_login()
            self.manager.current = "shell"
        else:
            self.error_label.text = "Incorrect password. Please try again."
