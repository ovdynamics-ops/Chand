"""inventory_screen.py - product list + add/edit/restock forms."""

from kivy.metrics import dp
from kivy.uix.screenmanager import Screen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.list import MDList, ThreeLineRightIconListItem, IconRightWidget
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.dialog import MDDialog

import db
import theme
from widgets import show_snackbar, confirm_dialog, info_dialog

CATEGORIES = ["Fridge", "AC", "Oven", "Washing Machine", "TV", "Freezer",
              "Water Dispenser", "Microwave", "Other"]


class InventoryScreen(Screen):
    def __init__(self, app_shell=None, **kwargs):
        super().__init__(**kwargs)
        self.app_shell = app_shell
        self.selected_product = None

        root = MDBoxLayout(orientation="vertical")

        top = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56), padding=(dp(12), 0),
                           spacing=dp(8))
        self.search_field = MDTextField(hint_text="Search products...", size_hint_x=0.7)
        self.search_field.bind(text=lambda *a: self.refresh())
        top.add_widget(self.search_field)
        add_btn = MDIconButton(icon="plus-circle", theme_text_color="Custom",
                                text_color=theme.hex_to_rgba(theme.PRIMARY),
                                on_release=lambda *a: self.open_form())
        top.add_widget(add_btn)
        root.add_widget(top)

        self.scroll = MDScrollView()
        self.list_widget = MDList()
        self.scroll.add_widget(self.list_widget)
        root.add_widget(self.scroll)

        self.add_widget(root)

    def refresh(self):
        self.list_widget.clear_widgets()
        products = db.get_products(search=self.search_field.text or None)
        for p in products:
            low = p["stock_qty"] <= p["min_stock"]
            secondary = f"{p['category']} - {p['brand'] or ''} {p['model'] or ''}".strip()
            tertiary = f"Stock: {p['stock_qty']}  |  Sale: {theme.currency(p['sale_price'])}"
            item = ThreeLineRightIconListItem(text=p["name"], secondary_text=secondary, tertiary_text=tertiary,
                                               on_release=self._make_open_handler(p["id"]))
            icon = IconRightWidget(icon="alert-circle" if low else "chevron-right",
                                    theme_text_color="Custom",
                                    text_color=theme.hex_to_rgba(theme.DANGER if low else theme.TEXT_MUTED))
            item.add_widget(icon)
            self.list_widget.add_widget(item)
        if self.app_shell:
            sales_screen = self.app_shell.inner_sm.get_screen("sales")
            sales_screen.refresh_products()

    def _make_open_handler(self, pid):
        def handler(*a):
            self.open_form(pid)
        return handler

    def open_form(self, pid=None):
        ProductFormScreen.open(self, pid)


class ProductFormScreen:
    """Opens a dialog-like full form using a MDDialog with scrollable content."""

    @staticmethod
    def open(inventory_screen, pid=None):
        prod = db.get_product(pid) if pid else None

        content = MDBoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None,
                               adaptive_height=True, padding=(0, dp(10)))

        name_field = MDTextField(hint_text="Product Name *", text=prod["name"] if prod else "")
        category_field = MDTextField(hint_text="Category * (e.g. Fridge, AC, Oven)",
                                      text=prod["category"] if prod else CATEGORIES[0])
        brand_field = MDTextField(hint_text="Brand", text=(prod["brand"] or "") if prod else "")
        model_field = MDTextField(hint_text="Model", text=(prod["model"] or "") if prod else "")
        purchase_field = MDTextField(hint_text="Purchase Price (Rs.) *", input_filter="float",
                                      text=str(prod["purchase_price"]) if prod else "")
        sale_field = MDTextField(hint_text="Sale Price (Rs.) *", input_filter="float",
                                  text=str(prod["sale_price"]) if prod else "")
        stock_field = MDTextField(hint_text="Opening Stock Qty" if not prod else "Stock Qty (use Restock to add)",
                                   input_filter="int", text=str(prod["stock_qty"]) if prod else "0",
                                   disabled=bool(prod))
        min_field = MDTextField(hint_text="Minimum Stock Alert Level", input_filter="int",
                                 text=str(prod["min_stock"]) if prod else "2")

        for f in [name_field, category_field, brand_field, model_field, purchase_field,
                  sale_field, stock_field, min_field]:
            content.add_widget(f)

        dialog = None

        def do_save(*a):
            name = name_field.text.strip()
            category = category_field.text.strip()
            if not name or not category:
                show_snackbar("Product name and category are required.")
                return
            try:
                purchase = float(purchase_field.text or 0)
                sale = float(sale_field.text or 0)
                min_stock = int(min_field.text or 0)
            except ValueError:
                show_snackbar("Prices and stock levels must be numeric.")
                return

            if prod is None:
                try:
                    stock = int(stock_field.text or 0)
                except ValueError:
                    show_snackbar("Opening stock must be a whole number.")
                    return
                db.add_product(name, category, brand_field.text.strip(), model_field.text.strip(),
                                purchase, sale, stock, min_stock)
                show_snackbar(f"Added {name}")
            else:
                db.update_product(pid, name, category, brand_field.text.strip(), model_field.text.strip(),
                                   purchase, sale, min_stock)
                show_snackbar(f"Updated {name}")

            dialog.dismiss()
            inventory_screen.refresh()

        def do_delete(*a):
            def confirmed():
                db.delete_product(pid)
                show_snackbar("Product deleted")
                dialog.dismiss()
                inventory_screen.refresh()
            confirm_dialog("Delete Product", f"Delete '{prod['name']}'? This cannot be undone.", confirmed)

        def do_restock(*a):
            dialog.dismiss()
            RestockForm.open(inventory_screen, pid)

        buttons = [MDFlatButton(text="Cancel", on_release=lambda *a: dialog.dismiss())]
        if prod:
            buttons.append(MDFlatButton(text="Restock", theme_text_color="Custom",
                                         text_color=theme.hex_to_rgba(theme.ACCENT), on_release=do_restock))
            buttons.append(MDFlatButton(text="Delete", theme_text_color="Custom",
                                         text_color=theme.hex_to_rgba(theme.DANGER), on_release=do_delete))
        buttons.append(MDRaisedButton(text="Save", md_bg_color=theme.hex_to_rgba(theme.PRIMARY),
                                       on_release=do_save))

        scroll = MDScrollView(size_hint_y=None, height=dp(420))
        scroll.add_widget(content)

        dialog = MDDialog(title="Add Product" if prod is None else "Edit Product",
                           type="custom", content_cls=scroll, buttons=buttons)
        dialog.open()


class RestockForm:
    @staticmethod
    def open(inventory_screen, pid):
        prod = db.get_product(pid)
        content = MDBoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None,
                               adaptive_height=True, padding=(0, dp(10)))
        content.add_widget(MDLabel(text=f"{prod['name']}  (current stock: {prod['stock_qty']})",
                                    size_hint_y=None, height=dp(40)))
        qty_field = MDTextField(hint_text="Quantity to add *", input_filter="int")
        cost_field = MDTextField(hint_text="Unit Purchase Cost (Rs.) - optional",
                                  input_filter="float", text=str(prod["purchase_price"]))
        content.add_widget(qty_field)
        content.add_widget(cost_field)

        dialog = None

        def do_save(*a):
            try:
                qty = int(qty_field.text)
                if qty <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                show_snackbar("Enter a valid positive quantity.")
                return
            cost = float(cost_field.text) if cost_field.text.strip() else None
            db.restock_product(pid, qty, cost)
            show_snackbar(f"Restocked {qty} units of {prod['name']}")
            dialog.dismiss()
            inventory_screen.refresh()

        dialog = MDDialog(title="Restock Product", type="custom", content_cls=content,
                           buttons=[MDFlatButton(text="Cancel", on_release=lambda *a: dialog.dismiss()),
                                    MDRaisedButton(text="Add Stock", md_bg_color=theme.hex_to_rgba(theme.PRIMARY),
                                                   on_release=do_save)])
        dialog.open()
