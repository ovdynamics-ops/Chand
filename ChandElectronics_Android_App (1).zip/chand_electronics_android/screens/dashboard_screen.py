"""dashboard_screen.py - overview stats for the Android app."""

from kivy.metrics import dp
from kivy.uix.screenmanager import Screen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.gridlayout import MDGridLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.list import MDList, TwoLineListItem

import db
import theme
from widgets import stat_card


class DashboardScreen(Screen):
    def __init__(self, app_shell=None, **kwargs):
        super().__init__(**kwargs)
        self.app_shell = app_shell

        self.scroll = MDScrollView()
        self.content = MDBoxLayout(orientation="vertical", padding=dp(14), spacing=dp(12),
                                    size_hint_y=None, adaptive_height=True)
        self.scroll.add_widget(self.content)
        self.add_widget(self.scroll)

        self.stats_grid = MDGridLayout(cols=2, spacing=dp(10), size_hint_y=None, adaptive_height=True)
        self.content.add_widget(self.stats_grid)

        self.content.add_widget(MDLabel(text="Low Stock Alerts", bold=True, font_style="Subtitle1",
                                         size_hint_y=None, height=dp(30)))
        self.low_stock_list = MDList()
        self.content.add_widget(self.low_stock_list)

        self.content.add_widget(MDLabel(text="Recent Sales", bold=True, font_style="Subtitle1",
                                         size_hint_y=None, height=dp(30)))
        self.recent_sales_list = MDList()
        self.content.add_widget(self.recent_sales_list)

    def refresh(self):
        self.stats_grid.clear_widgets()
        stats = db.dashboard_stats()
        cards = [
            ("This Month Sales", theme.currency(stats["month_sales_amount"]), theme.PRIMARY,
             f"{stats['month_sales_count']} invoices"),
            ("Receivable (Installments)", theme.currency(stats["total_receivable"]), theme.WARNING,
             f"{stats['overdue_installments']} overdue"),
            ("Net Balance", theme.currency(stats["net_balance"]), theme.SUCCESS, None),
            ("Low Stock Items", str(stats["low_stock"]), theme.DANGER, None),
            ("Total Products", str(stats["total_products"]), "#1B1F27", None),
            ("Total Customers", str(stats["total_customers"]), "#1B1F27", None),
        ]
        for title, value, color, sub in cards:
            self.stats_grid.add_widget(stat_card(title, value, color, sub))

        self.low_stock_list.clear_widgets()
        low = db.low_stock_products()
        if not low:
            self.low_stock_list.add_widget(TwoLineListItem(text="All stocked up", secondary_text="No low-stock items"))
        for p in low[:10]:
            self.low_stock_list.add_widget(TwoLineListItem(
                text=f"{p['name']}", secondary_text=f"{p['category']} - Stock: {p['stock_qty']} (min {p['min_stock']})"))

        self.recent_sales_list.clear_widgets()
        for s in db.get_sales()[:10]:
            self.recent_sales_list.add_widget(TwoLineListItem(
                text=f"{s['invoice_no']} - {s['customer_name'] or 'Walk-in'}",
                secondary_text=f"{s['sale_type']} - {theme.currency(s['net_amount'])} ({s['sale_date']})"))
