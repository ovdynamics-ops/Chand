"""installments_screen.py - installment plan list, schedule detail, payment recording."""

from kivy.metrics import dp
from kivy.uix.screenmanager import Screen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.list import MDList, TwoLineListItem, ThreeLineListItem
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.dialog import MDDialog

import db
import theme
from widgets import show_snackbar, info_dialog


class InstallmentsScreen(Screen):
    def __init__(self, app_shell=None, **kwargs):
        super().__init__(**kwargs)
        self.app_shell = app_shell

        root = MDBoxLayout(orientation="vertical")

        filt_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(44),
                                padding=(dp(8), 0), spacing=dp(6))
        self.status_filter = "All"
        for label in ["All", "Active", "Completed", "Overdue"]:
            filt_row.add_widget(MDFlatButton(text=label, on_release=self._make_filter_handler(label)))
        root.add_widget(filt_row)

        self.scroll = MDScrollView()
        self.list_widget = MDList()
        self.scroll.add_widget(self.list_widget)
        root.add_widget(self.scroll)

        self.add_widget(root)

    def _make_filter_handler(self, label):
        def handler(*a):
            self.status_filter = label
            self.refresh()
        return handler

    def refresh(self):
        self.list_widget.clear_widgets()
        status = None if self.status_filter in ("All", "Overdue") else self.status_filter
        overdue_only = self.status_filter == "Overdue"
        installments = db.get_installments(status=status, overdue_only=overdue_only)
        if not installments:
            self.list_widget.add_widget(TwoLineListItem(text="No installment plans", secondary_text="—"))
        for inst in installments:
            tag = " (OVERDUE)" if inst["overdue"] and inst["status"] != "Completed" else ""
            secondary = (f"Remaining: {theme.currency(inst['remaining'])}  |  "
                         f"Status: {inst['status']}{tag}")
            tertiary = f"Advance: {theme.currency(inst['advance_amount'])}  Financed: {theme.currency(inst['financed_amount'])}"
            item = ThreeLineListItem(text=f"{inst['invoice_no']} - {inst['customer_name'] or '-'}",
                                      secondary_text=secondary, tertiary_text=tertiary,
                                      on_release=self._make_open_handler(inst["id"]))
            self.list_widget.add_widget(item)

    def _make_open_handler(self, installment_id):
        def handler(*a):
            ScheduleDialog.open(self, installment_id)
        return handler


class ScheduleDialog:
    @staticmethod
    def open(installments_screen, installment_id):
        inst = db.get_installment(installment_id)
        if not inst:
            return

        content = MDBoxLayout(orientation="vertical", spacing=dp(6), size_hint_y=None,
                               adaptive_height=True, padding=(0, dp(8)))
        header = MDLabel(
            text=(f"{inst['customer_name'] or 'Customer'}\nInvoice {inst['invoice_no']}\n"
                  f"Advance {theme.currency(inst['advance_amount'])}  |  "
                  f"Financed {theme.currency(inst['financed_amount'])}  |  "
                  f"Monthly {theme.currency(inst['monthly_amount'])}\n"
                  f"Plan: {inst['num_months']} months  |  Status: {inst['status']}"),
            font_style="Caption", size_hint_y=None, height=dp(100))
        content.add_widget(header)

        schedule = db.get_schedule(installment_id)
        for s in schedule:
            row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(48), spacing=dp(6))
            color = theme.TEXT_MUTED
            if s["status"] == "Paid":
                color = theme.SUCCESS
            elif "Overdue" in s["status"]:
                color = theme.DANGER
            elif s["status"] == "Partial":
                color = theme.WARNING
            label_text = (f"M{s['month_no']}  {s['due_date']}  "
                          f"{theme.currency(s['due_amount'])}  "
                          f"(paid {theme.currency(s['paid_amount'])})  {s['status']}")
            row.add_widget(MDLabel(text=label_text, font_style="Caption", theme_text_color="Custom",
                                    text_color=theme.hex_to_rgba(color), size_hint_x=0.75))
            if s["status"] != "Paid":
                pay_btn = MDFlatButton(text="PAY", size_hint_x=0.25,
                                        on_release=ScheduleDialog._make_pay_handler(installments_screen, s))
                row.add_widget(pay_btn)
            content.add_widget(row)

        scroll = MDScrollView(size_hint_y=None, height=dp(420))
        scroll.add_widget(content)

        dialog = MDDialog(title="Installment Schedule", type="custom", content_cls=scroll,
                           buttons=[MDFlatButton(text="Close", on_release=lambda *a: dialog.dismiss())])
        dialog.open()

    @staticmethod
    def _make_pay_handler(installments_screen, schedule_row):
        def handler(*a):
            PaymentDialog.open(installments_screen, schedule_row)
        return handler


class PaymentDialog:
    @staticmethod
    def open(installments_screen, schedule_row):
        remaining_due = schedule_row["due_amount"] - schedule_row["paid_amount"]

        content = MDBoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None,
                               adaptive_height=True, padding=(0, dp(10)))
        content.add_widget(MDLabel(
            text=f"Month {schedule_row['month_no']}  -  Due {schedule_row['due_date']}\n"
                 f"Due: {theme.currency(schedule_row['due_amount'])}  "
                 f"Already paid: {theme.currency(schedule_row['paid_amount'])}",
            size_hint_y=None, height=dp(60)))
        amount_field = MDTextField(hint_text="Payment Amount (Rs.)", input_filter="float",
                                    text=f"{remaining_due:.0f}")
        note_field = MDTextField(hint_text="Note (optional)")
        content.add_widget(amount_field)
        content.add_widget(note_field)

        dialog = None

        def do_save(*a):
            try:
                amount = float(amount_field.text)
                if amount <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                show_snackbar("Enter a valid positive payment amount.")
                return
            db.record_installment_payment(schedule_row["id"], amount, notes=note_field.text.strip())
            show_snackbar(f"Payment of {theme.currency(amount)} recorded.")
            dialog.dismiss()
            installments_screen.refresh()
            if installments_screen.app_shell:
                installments_screen.app_shell.refresh_all()

        dialog = MDDialog(title="Record Payment", type="custom", content_cls=content,
                           buttons=[MDFlatButton(text="Cancel", on_release=lambda *a: dialog.dismiss()),
                                    MDRaisedButton(text="Record Payment",
                                                   md_bg_color=theme.hex_to_rgba(theme.SUCCESS),
                                                   on_release=do_save)])
        dialog.open()
