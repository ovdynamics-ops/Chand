"""customers_screen.py - customer list + add/edit forms."""

from kivy.metrics import dp
from kivy.uix.screenmanager import Screen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.list import MDList, TwoLineRightIconListItem, IconRightWidget
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.dialog import MDDialog

import db
import theme
from widgets import show_snackbar, confirm_dialog


class CustomersScreen(Screen):
    def __init__(self, app_shell=None, **kwargs):
        super().__init__(**kwargs)
        self.app_shell = app_shell

        root = MDBoxLayout(orientation="vertical")

        top = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(56), padding=(dp(12), 0),
                           spacing=dp(8))
        self.search_field = MDTextField(hint_text="Search customers...", size_hint_x=0.7)
        self.search_field.bind(text=lambda *a: self.refresh())
        top.add_widget(self.search_field)
        top.add_widget(MDIconButton(icon="account-plus", theme_text_color="Custom",
                                     text_color=theme.hex_to_rgba(theme.PRIMARY),
                                     on_release=lambda *a: self.open_form()))
        root.add_widget(top)

        self.scroll = MDScrollView()
        self.list_widget = MDList()
        self.scroll.add_widget(self.list_widget)
        root.add_widget(self.scroll)

        self.add_widget(root)

    def refresh(self):
        self.list_widget.clear_widgets()
        for c in db.get_customers(search=self.search_field.text or None):
            item = TwoLineRightIconListItem(text=c["name"],
                                             secondary_text=f"{c['phone'] or 'No phone'}  |  {c['address'] or ''}",
                                             on_release=self._make_open_handler(c["id"]))
            item.add_widget(IconRightWidget(icon="chevron-right"))
            self.list_widget.add_widget(item)
        if self.app_shell:
            self.app_shell.inner_sm.get_screen("sales").refresh_customers()

    def _make_open_handler(self, cid):
        def handler(*a):
            self.open_form(cid)
        return handler

    def open_form(self, cid=None):
        cust = db.get_customer(cid) if cid else None

        content = MDBoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None,
                               adaptive_height=True, padding=(0, dp(10)))
        name_field = MDTextField(hint_text="Full Name *", text=cust["name"] if cust else "")
        phone_field = MDTextField(hint_text="Phone Number", text=(cust["phone"] or "") if cust else "")
        cnic_field = MDTextField(hint_text="CNIC", text=(cust["cnic"] or "") if cust else "")
        address_field = MDTextField(hint_text="Address", text=(cust["address"] or "") if cust else "")
        for f in [name_field, phone_field, cnic_field, address_field]:
            content.add_widget(f)

        dialog = None

        def do_save(*a):
            name = name_field.text.strip()
            if not name:
                show_snackbar("Customer name is required.")
                return
            if cust is None:
                db.add_customer(name, phone_field.text.strip(), cnic_field.text.strip(),
                                 address_field.text.strip())
                show_snackbar(f"Added {name}")
            else:
                db.update_customer(cid, name, phone_field.text.strip(), cnic_field.text.strip(),
                                    address_field.text.strip())
                show_snackbar(f"Updated {name}")
            dialog.dismiss()
            self.refresh()

        def do_delete(*a):
            def confirmed():
                db.delete_customer(cid)
                show_snackbar("Customer deleted")
                dialog.dismiss()
                self.refresh()
            confirm_dialog("Delete Customer", f"Delete '{cust['name']}'?", confirmed)

        buttons = [MDFlatButton(text="Cancel", on_release=lambda *a: dialog.dismiss())]
        if cust:
            buttons.append(MDFlatButton(text="Delete", theme_text_color="Custom",
                                         text_color=theme.hex_to_rgba(theme.DANGER), on_release=do_delete))
        buttons.append(MDRaisedButton(text="Save", md_bg_color=theme.hex_to_rgba(theme.PRIMARY),
                                       on_release=do_save))

        dialog = MDDialog(title="Add Customer" if cust is None else "Edit Customer",
                           type="custom", content_cls=content, buttons=buttons)
        dialog.open()
