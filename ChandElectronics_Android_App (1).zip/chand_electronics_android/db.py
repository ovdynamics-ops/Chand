"""
db.py - Database layer for Chand Electronics Shop Management System
Handles schema creation and all data access (inventory, customers, sales,
installments, accounts ledger).
"""

import sqlite3
import os
from datetime import datetime, date

try:
    from kivy.utils import platform as _kivy_platform
except Exception:
    _kivy_platform = "linux"

if _kivy_platform == "android":
    try:
        from android.storage import app_storage_path
        _DB_DIR = app_storage_path()
    except Exception:
        _DB_DIR = os.path.dirname(os.path.abspath(__file__))
else:
    _DB_DIR = os.path.dirname(os.path.abspath(__file__))

os.makedirs(_DB_DIR, exist_ok=True)
DB_FILE = os.path.join(_DB_DIR, "chand_electronics.db")


def get_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_connection()
    cur = conn.cursor()

    cur.executescript("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    );

    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        brand TEXT,
        model TEXT,
        purchase_price REAL NOT NULL DEFAULT 0,
        sale_price REAL NOT NULL DEFAULT 0,
        stock_qty INTEGER NOT NULL DEFAULT 0,
        min_stock INTEGER NOT NULL DEFAULT 2,
        created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        cnic TEXT,
        address TEXT,
        created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_no TEXT UNIQUE,
        sale_date TEXT,
        customer_id INTEGER,
        sale_type TEXT,
        gross_amount REAL,
        discount REAL,
        net_amount REAL,
        notes TEXT,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    );

    CREATE TABLE IF NOT EXISTS sale_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sale_id INTEGER,
        product_id INTEGER,
        product_name TEXT,
        qty INTEGER,
        unit_price REAL,
        total_price REAL,
        FOREIGN KEY(sale_id) REFERENCES sales(id),
        FOREIGN KEY(product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS installments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sale_id INTEGER,
        advance_amount REAL,
        financed_amount REAL,
        num_months INTEGER,
        monthly_amount REAL,
        start_date TEXT,
        status TEXT DEFAULT 'Active',
        FOREIGN KEY(sale_id) REFERENCES sales(id)
    );

    CREATE TABLE IF NOT EXISTS installment_schedule (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        installment_id INTEGER,
        month_no INTEGER,
        due_date TEXT,
        due_amount REAL,
        paid_amount REAL DEFAULT 0,
        paid_date TEXT,
        status TEXT DEFAULT 'Pending',
        FOREIGN KEY(installment_id) REFERENCES installments(id)
    );

    CREATE TABLE IF NOT EXISTS accounts_ledger (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_date TEXT,
        entry_type TEXT,
        category TEXT,
        description TEXT,
        amount REAL,
        reference TEXT,
        created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS stock_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        move_date TEXT,
        move_type TEXT,
        qty INTEGER,
        notes TEXT
    );

    CREATE TABLE IF NOT EXISTS returns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        return_date TEXT,
        customer_name TEXT,
        sale_id INTEGER,
        product_id INTEGER,
        product_name TEXT,
        qty INTEGER,
        reason TEXT,
        refund_amount REAL DEFAULT 0,
        restocked INTEGER DEFAULT 1,
        created_at TEXT,
        FOREIGN KEY(sale_id) REFERENCES sales(id),
        FOREIGN KEY(product_id) REFERENCES products(id)
    );
    """)

    # --- lightweight migrations for installs created before profit-margin /
    # returns support was added -----------------------------------------
    def _ensure_column(table, col_def):
        col_name = col_def.split()[0]
        cols = [r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]
        if col_name not in cols:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col_def}")

    _ensure_column("sales", "profit_mode TEXT")            # NULL / 'flat' / 'per_item'
    _ensure_column("sales", "profit_percent REAL")          # used when profit_mode='flat'
    _ensure_column("sales", "installment_price REAL")       # net_amount + profit, basis for financing
    _ensure_column("sale_items", "profit_percent REAL")     # used when profit_mode='per_item'
    _ensure_column("sale_items", "item_price_with_profit REAL")
    conn.commit()

    cur.execute("SELECT value FROM settings WHERE key='admin_password'")
    if cur.fetchone() is None:
        cur.execute("INSERT INTO settings (key, value) VALUES ('admin_password', 'admin123')")
    cur.execute("SELECT value FROM settings WHERE key='shop_name'")
    if cur.fetchone() is None:
        cur.execute("INSERT INTO settings (key, value) VALUES ('shop_name', 'Chand Electronics')")
    cur.execute("SELECT value FROM settings WHERE key='next_invoice'")
    if cur.fetchone() is None:
        cur.execute("INSERT INTO settings (key, value) VALUES ('next_invoice', '1')")

    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Settings / auth
# ---------------------------------------------------------------------------

def get_setting(key, default=None):
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key, value):
    conn = get_connection()
    conn.execute("INSERT INTO settings (key, value) VALUES (?, ?) "
                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))
    conn.commit()
    conn.close()


def check_password(password):
    return get_setting("admin_password", "admin123") == password


def change_password(new_password):
    set_setting("admin_password", new_password)


def next_invoice_no():
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='next_invoice'").fetchone()
    n = int(row["value"]) if row else 1
    conn.execute("UPDATE settings SET value=? WHERE key='next_invoice'", (str(n + 1),))
    conn.commit()
    conn.close()
    return f"INV-{n:05d}"


# ---------------------------------------------------------------------------
# Products / Inventory
# ---------------------------------------------------------------------------

def add_product(name, category, brand, model, purchase_price, sale_price, stock_qty, min_stock):
    conn = get_connection()
    conn.execute("""INSERT INTO products
        (name, category, brand, model, purchase_price, sale_price, stock_qty, min_stock, created_at)
        VALUES (?,?,?,?,?,?,?,?,?)""",
        (name, category, brand, model, purchase_price, sale_price, stock_qty, min_stock,
         datetime.now().isoformat()))
    pid = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
    if stock_qty:
        conn.execute("""INSERT INTO stock_movements (product_id, move_date, move_type, qty, notes)
                         VALUES (?,?,?,?,?)""",
                     (pid, date.today().isoformat(), "Purchase", stock_qty, "Initial stock"))
    conn.commit()
    conn.close()
    return pid


def update_product(pid, name, category, brand, model, purchase_price, sale_price, min_stock):
    conn = get_connection()
    conn.execute("""UPDATE products SET name=?, category=?, brand=?, model=?,
                     purchase_price=?, sale_price=?, min_stock=? WHERE id=?""",
                 (name, category, brand, model, purchase_price, sale_price, min_stock, pid))
    conn.commit()
    conn.close()


def delete_product(pid):
    conn = get_connection()
    conn.execute("DELETE FROM products WHERE id=?", (pid,))
    conn.commit()
    conn.close()


def get_products(search=None, category=None):
    conn = get_connection()
    q = "SELECT * FROM products WHERE 1=1"
    params = []
    if search:
        q += " AND (name LIKE ? OR brand LIKE ? OR model LIKE ?)"
        s = f"%{search}%"
        params += [s, s, s]
    if category and category != "All":
        q += " AND category=?"
        params.append(category)
    q += " ORDER BY name"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return rows


def get_product(pid):
    conn = get_connection()
    row = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    conn.close()
    return row


def get_categories():
    conn = get_connection()
    rows = conn.execute("SELECT DISTINCT category FROM products ORDER BY category").fetchall()
    conn.close()
    cats = [r["category"] for r in rows]
    defaults = ["Fridge", "AC", "Oven", "Washing Machine", "TV", "Freezer", "Water Dispenser", "Other"]
    for d in defaults:
        if d not in cats:
            cats.append(d)
    return sorted(set(cats))


def adjust_stock(pid, qty_change, move_type, notes=""):
    """qty_change positive = stock in (purchase/return), negative = stock out (sale)."""
    conn = get_connection()
    conn.execute("UPDATE products SET stock_qty = stock_qty + ? WHERE id=?", (qty_change, pid))
    conn.execute("""INSERT INTO stock_movements (product_id, move_date, move_type, qty, notes)
                     VALUES (?,?,?,?,?)""",
                 (pid, date.today().isoformat(), move_type, qty_change, notes))
    conn.commit()
    conn.close()


def restock_product(pid, qty, unit_cost=None):
    conn = get_connection()
    conn.execute("UPDATE products SET stock_qty = stock_qty + ? WHERE id=?", (qty, pid))
    if unit_cost is not None:
        conn.execute("UPDATE products SET purchase_price=? WHERE id=?", (unit_cost, pid))
    conn.execute("""INSERT INTO stock_movements (product_id, move_date, move_type, qty, notes)
                     VALUES (?,?,?,?,?)""",
                 (pid, date.today().isoformat(), "Purchase", qty, "Restock"))
    total_cost = (unit_cost or 0) * qty
    if total_cost > 0:
        add_ledger_entry(date.today().isoformat(), "Expense", "Purchase",
                          f"Stock purchase (product #{pid}) x{qty}", total_cost, f"product:{pid}")
    conn.commit()
    conn.close()


def low_stock_products():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM products WHERE stock_qty <= min_stock ORDER BY stock_qty ASC").fetchall()
    conn.close()
    return rows


# ---------------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------------

def add_customer(name, phone, cnic, address):
    conn = get_connection()
    conn.execute("INSERT INTO customers (name, phone, cnic, address, created_at) VALUES (?,?,?,?,?)",
                 (name, phone, cnic, address, datetime.now().isoformat()))
    cid = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
    conn.commit()
    conn.close()
    return cid


def update_customer(cid, name, phone, cnic, address):
    conn = get_connection()
    conn.execute("UPDATE customers SET name=?, phone=?, cnic=?, address=? WHERE id=?",
                 (name, phone, cnic, address, cid))
    conn.commit()
    conn.close()


def delete_customer(cid):
    conn = get_connection()
    conn.execute("DELETE FROM customers WHERE id=?", (cid,))
    conn.commit()
    conn.close()


def get_customers(search=None):
    conn = get_connection()
    q = "SELECT * FROM customers WHERE 1=1"
    params = []
    if search:
        q += " AND (name LIKE ? OR phone LIKE ? OR cnic LIKE ?)"
        s = f"%{search}%"
        params += [s, s, s]
    q += " ORDER BY name"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return rows


def get_customer(cid):
    conn = get_connection()
    row = conn.execute("SELECT * FROM customers WHERE id=?", (cid,)).fetchone()
    conn.close()
    return row


# ---------------------------------------------------------------------------
# Accounts ledger
# ---------------------------------------------------------------------------

def add_ledger_entry(entry_date, entry_type, category, description, amount, reference=""):
    conn = get_connection()
    conn.execute("""INSERT INTO accounts_ledger
        (entry_date, entry_type, category, description, amount, reference, created_at)
        VALUES (?,?,?,?,?,?,?)""",
        (entry_date, entry_type, category, description, amount, reference, datetime.now().isoformat()))
    conn.commit()
    conn.close()


def get_ledger_entries(date_from=None, date_to=None, entry_type=None):
    conn = get_connection()
    q = "SELECT * FROM accounts_ledger WHERE 1=1"
    params = []
    if date_from:
        q += " AND entry_date >= ?"
        params.append(date_from)
    if date_to:
        q += " AND entry_date <= ?"
        params.append(date_to)
    if entry_type and entry_type != "All":
        q += " AND entry_type=?"
        params.append(entry_type)
    q += " ORDER BY entry_date DESC, id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return rows


def ledger_totals(date_from=None, date_to=None):
    conn = get_connection()
    q_income = "SELECT COALESCE(SUM(amount),0) AS t FROM accounts_ledger WHERE entry_type='Income'"
    q_expense = "SELECT COALESCE(SUM(amount),0) AS t FROM accounts_ledger WHERE entry_type='Expense'"
    params = []
    if date_from:
        q_income += " AND entry_date >= ?"
        q_expense += " AND entry_date >= ?"
        params.append(date_from)
    if date_to:
        q_income += " AND entry_date <= ?"
        q_expense += " AND entry_date <= ?"
    income = conn.execute(q_income, ([date_from] if date_from else []) +
                           ([date_to] if date_to else [])).fetchone()["t"]
    expense = conn.execute(q_expense, ([date_from] if date_from else []) +
                            ([date_to] if date_to else [])).fetchone()["t"]
    conn.close()
    return income, expense, income - expense


# ---------------------------------------------------------------------------
# Sales (Cash + Installment)
# ---------------------------------------------------------------------------

def create_sale(customer_id, sale_type, items, discount, notes="", profit_mode=None, profit_percent=None):
    """
    items: list of dicts {product_id, product_name, qty, unit_price[, profit_percent]}
    Deducts stock and creates the sales/sale_items rows. Returns
    (sale_id, invoice_no, net_amount, installment_price).

    profit_mode: None (cash / no markup), 'flat' (apply profit_percent to the
    whole net total), or 'per_item' (each item dict may carry its own
    'profit_percent', defaulting to 0 if omitted).
    installment_price is the net_amount plus the calculated profit markup -
    this is the figure installment plans should be financed against. It is
    None when profit_mode is None.

    Does NOT record the accounts ledger entry - caller handles that
    (cash sale records full amount, installment sale records advance only).
    """
    gross = sum(i["qty"] * i["unit_price"] for i in items)
    net = max(gross - discount, 0)

    installment_price = None
    if profit_mode == "per_item":
        total_with_profit = 0.0
        for it in items:
            pct = it.get("profit_percent") or 0
            item_total = it["qty"] * it["unit_price"]
            item_with_profit = item_total * (1 + pct / 100)
            it["_item_price_with_profit"] = round(item_with_profit, 2)
            total_with_profit += item_with_profit
        installment_price = max(round(total_with_profit - discount, 2), 0)
    elif profit_mode == "flat":
        pct = profit_percent or 0
        installment_price = round(net * (1 + pct / 100), 2)

    invoice_no = next_invoice_no()
    conn = get_connection()
    conn.execute("""INSERT INTO sales (invoice_no, sale_date, customer_id, sale_type,
                     gross_amount, discount, net_amount, notes, profit_mode, profit_percent,
                     installment_price)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                 (invoice_no, date.today().isoformat(), customer_id, sale_type,
                  gross, discount, net, notes, profit_mode, profit_percent, installment_price))
    sale_id = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    for it in items:
        total_price = it["qty"] * it["unit_price"]
        item_pct = it.get("profit_percent") if profit_mode == "per_item" else None
        item_with_profit = it.get("_item_price_with_profit") if profit_mode == "per_item" else None
        conn.execute("""INSERT INTO sale_items
                         (sale_id, product_id, product_name, qty, unit_price, total_price,
                          profit_percent, item_price_with_profit)
                         VALUES (?,?,?,?,?,?,?,?)""",
                     (sale_id, it["product_id"], it["product_name"], it["qty"], it["unit_price"],
                      total_price, item_pct, item_with_profit))
        conn.execute("UPDATE products SET stock_qty = stock_qty - ? WHERE id=?", (it["qty"], it["product_id"]))
        conn.execute("""INSERT INTO stock_movements (product_id, move_date, move_type, qty, notes)
                         VALUES (?,?,?,?,?)""",
                     (it["product_id"], date.today().isoformat(), "Sale", -it["qty"], f"Invoice {invoice_no}"))
    conn.commit()
    conn.close()
    return sale_id, invoice_no, net, installment_price


def finalize_cash_sale(customer_id, items, discount, notes=""):
    sale_id, invoice_no, net, _ = create_sale(customer_id, "Cash", items, discount, notes)
    add_ledger_entry(date.today().isoformat(), "Income", "Sale",
                      f"Cash sale invoice {invoice_no}", net, f"sale:{sale_id}")
    return sale_id, invoice_no, net


def _add_months(d: date, months: int) -> date:
    month = d.month - 1 + months
    year = d.year + month // 12
    month = month % 12 + 1
    day = min(d.day, [31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28,
                       31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1])
    return date(year, month, day)


def finalize_installment_sale(customer_id, items, discount, advance_amount, num_months=12, notes="",
                               profit_mode=None, profit_percent=None):
    """
    Creates the sale, deducts stock, records the advance as income,
    then builds an equal 12-month (or custom) installment schedule for the
    remaining (financed) amount.

    profit_mode/profit_percent: see create_sale(). When set, the installment
    plan is financed against net_amount + profit markup (e.g. a 35% markup
    for installment vs cash pricing) instead of the plain net_amount.
    """
    sale_id, invoice_no, net, installment_price = create_sale(
        customer_id, "Installment", items, discount, notes, profit_mode, profit_percent)

    base_amount = installment_price if installment_price is not None else net
    financed = max(base_amount - advance_amount, 0)
    monthly = round(financed / num_months, 2) if num_months else 0
    start = date.today()

    conn = get_connection()
    conn.execute("""INSERT INTO installments
        (sale_id, advance_amount, financed_amount, num_months, monthly_amount, start_date, status)
        VALUES (?,?,?,?,?,?, 'Active')""",
        (sale_id, advance_amount, financed, num_months, monthly, start.isoformat()))
    installment_id = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    remaining = financed
    for m in range(1, num_months + 1):
        due_date = _add_months(start, m)
        if m == num_months:
            amt = round(remaining, 2)  # last installment absorbs rounding remainder
        else:
            amt = monthly
            remaining -= monthly
        conn.execute("""INSERT INTO installment_schedule
            (installment_id, month_no, due_date, due_amount, paid_amount, status)
            VALUES (?,?,?,?,0,'Pending')""",
            (installment_id, m, due_date.isoformat(), amt))

    conn.commit()
    conn.close()

    if advance_amount > 0:
        add_ledger_entry(date.today().isoformat(), "Income", "Installment Advance",
                          f"Advance for invoice {invoice_no}", advance_amount, f"sale:{sale_id}")

    return sale_id, invoice_no, installment_id


def get_sales(sale_type=None, date_from=None, date_to=None, customer_id=None):
    conn = get_connection()
    q = """SELECT s.*, c.name AS customer_name, c.phone AS customer_phone
           FROM sales s LEFT JOIN customers c ON s.customer_id = c.id WHERE 1=1"""
    params = []
    if sale_type and sale_type != "All":
        q += " AND s.sale_type=?"
        params.append(sale_type)
    if date_from:
        q += " AND s.sale_date >= ?"
        params.append(date_from)
    if date_to:
        q += " AND s.sale_date <= ?"
        params.append(date_to)
    if customer_id:
        q += " AND s.customer_id=?"
        params.append(customer_id)
    q += " ORDER BY s.sale_date DESC, s.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return rows


def get_sale_items(sale_id):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM sale_items WHERE sale_id=?", (sale_id,)).fetchall()
    conn.close()
    return rows


# ---------------------------------------------------------------------------
# Installments
# ---------------------------------------------------------------------------

def get_installments(status=None, overdue_only=False):
    conn = get_connection()
    q = """SELECT i.*, s.invoice_no, s.net_amount, s.sale_date, c.name AS customer_name,
                  c.phone AS customer_phone
           FROM installments i
           JOIN sales s ON i.sale_id = s.id
           LEFT JOIN customers c ON s.customer_id = c.id WHERE 1=1"""
    params = []
    if status and status != "All":
        q += " AND i.status=?"
        params.append(status)
    q += " ORDER BY i.start_date DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    result = []
    today = date.today().isoformat()
    for r in rows:
        sched = conn2 = None
        sched = get_schedule(r["id"])
        paid = sum(x["paid_amount"] for x in sched)
        due_total = sum(x["due_amount"] for x in sched)
        overdue = any(x["status"] in ("Pending", "Partial") and x["due_date"] < today for x in sched)
        next_due = next((x for x in sched if x["status"] in ("Pending", "Partial")), None)
        d = dict(r)
        d["total_paid_installments"] = paid
        d["total_due_installments"] = due_total
        d["remaining"] = due_total - paid
        d["overdue"] = overdue
        d["next_due_date"] = next_due["due_date"] if next_due else None
        d["next_due_amount"] = (next_due["due_amount"] - next_due["paid_amount"]) if next_due else 0
        if overdue_only and not overdue:
            continue
        result.append(d)
    return result


def get_installment(installment_id):
    conn = get_connection()
    row = conn.execute("""SELECT i.*, s.invoice_no, s.net_amount, s.sale_date, c.name AS customer_name,
                                  c.phone AS customer_phone, c.address AS customer_address
                           FROM installments i
                           JOIN sales s ON i.sale_id = s.id
                           LEFT JOIN customers c ON s.customer_id = c.id
                           WHERE i.id=?""", (installment_id,)).fetchone()
    conn.close()
    return row


def get_schedule(installment_id):
    conn = get_connection()
    rows = conn.execute("""SELECT * FROM installment_schedule WHERE installment_id=?
                            ORDER BY month_no""", (installment_id,)).fetchall()
    conn.close()
    today = date.today().isoformat()
    result = []
    for r in rows:
        d = dict(r)
        if d["status"] in ("Pending", "Partial") and d["due_date"] < today:
            d["status"] = "Overdue" if d["paid_amount"] == 0 else "Partial (Overdue)"
        result.append(d)
    return result


def record_installment_payment(schedule_id, amount, pay_date=None, notes=""):
    pay_date = pay_date or date.today().isoformat()
    conn = get_connection()
    row = conn.execute("SELECT * FROM installment_schedule WHERE id=?", (schedule_id,)).fetchone()
    if row is None:
        conn.close()
        return False
    new_paid = row["paid_amount"] + amount
    if new_paid >= row["due_amount"] - 0.01:
        status = "Paid"
    else:
        status = "Partial"
    conn.execute("""UPDATE installment_schedule SET paid_amount=?, paid_date=?, status=?
                     WHERE id=?""", (new_paid, pay_date, status, schedule_id))

    inst = conn.execute("SELECT * FROM installments WHERE id=?", (row["installment_id"],)).fetchone()
    conn.commit()

    invoice_no = conn.execute("SELECT invoice_no FROM sales WHERE id=?", (inst["sale_id"],)).fetchone()["invoice_no"]
    add_ledger_entry(pay_date, "Income", "Installment Payment",
                      f"Installment #{row['month_no']} payment for invoice {invoice_no}"
                      + (f" - {notes}" if notes else ""),
                      amount, f"installment:{inst['id']}")

    all_sched = conn.execute("SELECT * FROM installment_schedule WHERE installment_id=?",
                              (row["installment_id"],)).fetchall()
    if all(s["status"] == "Paid" for s in all_sched):
        conn.execute("UPDATE installments SET status='Completed' WHERE id=?", (row["installment_id"],))
        conn.commit()
    conn.close()
    return True


# ---------------------------------------------------------------------------
# Dashboard stats
# ---------------------------------------------------------------------------

def dashboard_stats():
    conn = get_connection()
    total_products = conn.execute("SELECT COUNT(*) AS c FROM products").fetchone()["c"]
    total_stock_value = conn.execute(
        "SELECT COALESCE(SUM(stock_qty * purchase_price),0) AS v FROM products").fetchone()["v"]
    low_stock = conn.execute("SELECT COUNT(*) AS c FROM products WHERE stock_qty <= min_stock").fetchone()["c"]

    today = date.today()
    month_start = today.replace(day=1).isoformat()
    month_sales = conn.execute(
        "SELECT COALESCE(SUM(net_amount),0) AS v, COUNT(*) AS c FROM sales WHERE sale_date >= ?",
        (month_start,)).fetchone()

    total_customers = conn.execute("SELECT COUNT(*) AS c FROM customers").fetchone()["c"]

    conn.close()

    installments = get_installments()
    total_receivable = sum(i["remaining"] for i in installments if i["status"] != "Completed")
    overdue_count = sum(1 for i in installments if i["overdue"])

    income, expense, balance = ledger_totals()

    return {
        "total_products": total_products,
        "total_stock_value": total_stock_value,
        "low_stock": low_stock,
        "month_sales_amount": month_sales["v"],
        "month_sales_count": month_sales["c"],
        "total_customers": total_customers,
        "total_receivable": total_receivable,
        "overdue_installments": overdue_count,
        "total_income": income,
        "total_expense": expense,
        "net_balance": balance,
    }


# ---------------------------------------------------------------------------
# Returns
# ---------------------------------------------------------------------------

def get_sale(sale_id):
    conn = get_connection()
    row = conn.execute("""SELECT s.*, c.name AS customer_name, c.phone AS customer_phone
                           FROM sales s LEFT JOIN customers c ON s.customer_id = c.id
                           WHERE s.id=?""", (sale_id,)).fetchone()
    conn.close()
    return row


def process_return(return_date, customer_name, product_id, product_name, qty, reason,
                    refund_amount, sale_id=None, restock=True):
    """
    Records a returned item. By default puts the quantity back into stock
    and logs a matching 'Sales Return' expense entry (money paid back /
    value given up) in the accounts ledger so the net balance reflects it.
    """
    conn = get_connection()
    conn.execute("""INSERT INTO returns
        (return_date, customer_name, sale_id, product_id, product_name, qty, reason,
         refund_amount, restocked, created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (return_date, customer_name, sale_id, product_id, product_name, qty, reason,
         refund_amount, 1 if restock else 0, datetime.now().isoformat()))
    return_id = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    if restock and product_id:
        conn.execute("UPDATE products SET stock_qty = stock_qty + ? WHERE id=?", (qty, product_id))
        conn.execute("""INSERT INTO stock_movements (product_id, move_date, move_type, qty, notes)
                         VALUES (?,?,?,?,?)""",
                     (product_id, return_date, "Return",
                      qty, f"Return from {customer_name}" + (f" (sale #{sale_id})" if sale_id else "")))
    conn.commit()
    conn.close()

    if refund_amount and refund_amount > 0:
        ref = f"return:{return_id}" + (f" sale:{sale_id}" if sale_id else "")
        add_ledger_entry(return_date, "Expense", "Sales Return",
                          f"Return by {customer_name} - {product_name} x{qty} ({reason})",
                          refund_amount, ref)
    return return_id


def get_returns(date_from=None, date_to=None, search=None):
    conn = get_connection()
    q = "SELECT r.*, s.invoice_no FROM returns r LEFT JOIN sales s ON r.sale_id = s.id WHERE 1=1"
    params = []
    if date_from:
        q += " AND r.return_date >= ?"
        params.append(date_from)
    if date_to:
        q += " AND r.return_date <= ?"
        params.append(date_to)
    if search:
        q += " AND (r.customer_name LIKE ? OR r.product_name LIKE ? OR r.reason LIKE ?)"
        s = f"%{search}%"
        params += [s, s, s]
    q += " ORDER BY r.return_date DESC, r.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return rows
