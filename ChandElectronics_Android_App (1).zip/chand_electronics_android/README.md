# Chand Electronics – Android App (Mobile)

A Kivy/KivyMD Android app sharing the same shop-management logic as the
Windows desktop edition (Inventory, Customers, Sales, Installments, Returns,
Accounts) — built for touch, installable as a real `.apk`.

I built, ran, and functionally tested this app (login, every screen, a cash
sale, a 35%-markup installment sale with its 12-month schedule, a payment,
and a return) in a Linux test environment before handing it to you. The only
step left is compiling it into an `.apk`, which needs the Android SDK/NDK —
a large toolchain that has to run on a real machine, so I can't produce the
compiled file myself. Below is the one-command build.

## 1. What you need

- A **Linux** machine or VM (Buildozer/python-for-android only build on
  Linux — WSL2 on Windows works fine, see below).
- Python 3.10–3.12 and the Buildozer tool.

If you're on Windows, the easiest path is:
1. Install **WSL2** (Windows Subsystem for Linux): open PowerShell as
   Administrator and run `wsl --install`, then restart and set up an Ubuntu
   user when prompted.
2. Open the Ubuntu/WSL terminal and follow the Linux steps below.

If you don't want to set any of this up yourself, another option is a free
**Google Colab** notebook (also Linux-based) — copy this folder there and run
the same commands in a notebook cell with `!` in front of each line.

## 2. One-time setup (Linux / WSL2 / Colab)

```bash
sudo apt update
sudo apt install -y python3-pip build-essential git python3-dev ffmpeg \
    libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev \
    libportmidi-dev libswscale-dev libavformat-dev libavcodec-dev \
    zlib1g-dev openjdk-17-jdk unzip

pip3 install --upgrade buildozer cython==0.29.36
```

## 3. Build the APK

From inside this `chand_electronics_android` folder:

```bash
buildozer -v android debug
```

- First run downloads the Android SDK/NDK automatically (several GB — needs
  a good internet connection and can take 20–60 minutes). Every build after
  that is much faster.
- When it finishes, your APK is at:
  ```
  bin/chandelectronics-1.0-arm64-v8a_armeabi-v7a-debug.apk
  ```

## 4. Install it on a phone

- **Directly**: plug your Android phone into the Linux machine via USB, turn
  on "USB debugging" in Developer Options, then run:
  ```
  buildozer android deploy run
  ```
- **Manually**: copy the `.apk` file from `bin/` to your phone (email it to
  yourself, use a USB cable, Google Drive, etc.) and tap it to install. You
  may need to allow "Install unknown apps" for your file manager/browser the
  first time.

## 5. First Login

- Default admin password: **admin123**
- (Change-password screen isn't wired into the mobile UI in this version —
  it's exposed via `db.change_password()` if you'd like it added; the
  Windows app already has a "Change Password" button.)

## 6. Features

All data lives in a local SQLite database on the device
(`chand_electronics.db`, stored in the app's private storage), fully offline.

### Dashboard
Stat cards: this month's sales, installment receivables + overdue count, net
account balance, low-stock count, product/customer totals. Recent sales and
low-stock alerts below.

### Inventory
Tap **+** to add a product (name, category, brand, model, purchase/sale
price, opening stock, min-stock alert). Tap any product to edit, delete, or
**Restock** it (restocking optionally updates cost and logs a Purchase
expense).

### Customers
Tap **+** to add a customer (name, phone, CNIC, address). Tap any customer to
edit or delete.

### Sales
Two views inside this screen — **New Sale** and **History**.
- **New Sale**: pick a customer, add products to the cart, apply a discount,
  choose **Cash** or **Installment**.
  - **Cash** — charges the full net amount immediately.
  - **Installment** — enter the advance payment and number of months
    (defaults to **12**). Then choose a profit margin:
    - **None** — plan is financed against the plain net total.
    - **Flat %** — one percentage (defaults to **35%**) applied to the whole
      sale, e.g. Rs. 89,000 → Rs. 120,150 installment price at 35%.
    - **Per Item %** — tap "Set Profit % per Item" to give each cart item its
      own percentage.
  - A live preview shows the profit markup, installment price, financed
    amount, and monthly installment before you confirm.
- **History**: filter Cash/Installment, tap any invoice to see its items.

### Installments
Tap any plan to open its full month-by-month schedule (due date, due amount,
paid amount, status). Tap **PAY** next to any unpaid month to record a full
or partial payment — it's logged straight into Accounts.

### Returns
Tap **+** to process a return: optionally link the original sale (auto-fills
customer/product/qty/refund), or fill in manually. Required: **customer
name**, **product**, **quantity**, **return date**, **reason**. Restocks the
item automatically and logs a "Sales Return" expense in Accounts.

### Accounts
Income/Expense/Net Balance summary cards plus the full ledger. Tap the
cash-minus icon to add a manual expense (rent, salary, utilities, etc.).

## 7. Project Structure

```
chand_electronics_android/
├── main.py                    # entry point
├── buildozer.spec             # Android build configuration
├── db.py                      # database logic (same schema as desktop)
├── theme.py                   # shared colors
├── widgets.py                 # reusable stat cards / dialogs
├── icon.png                   # placeholder app icon (replace with your own)
├── screens/
│   ├── login_screen.py
│   ├── shell_screen.py        # top bar + navigation drawer
│   ├── dashboard_screen.py
│   ├── inventory_screen.py
│   ├── customers_screen.py
│   ├── sales_screen.py
│   ├── installments_screen.py
│   ├── returns_screen.py
│   └── accounts_screen.py
└── README.md
```

## 8. Notes

- To use your own icon, replace `icon.png` (512x512 recommended) before
  building.
- To change the shop name/branding, edit the strings in
  `screens/login_screen.py` and `screens/shell_screen.py`.
- If `buildozer android debug` fails partway through a dependency download,
  just re-run the same command — it resumes/retries automatically.
- The `bin/`, `.buildozer/`, and `.gradle/` folders that appear after your
  first build are large — safe to delete and rebuild if you need to save
  space, but deleting `.buildozer` means the SDK/NDK re-downloads next time.
