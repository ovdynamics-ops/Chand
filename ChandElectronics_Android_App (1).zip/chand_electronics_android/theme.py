"""theme.py - shared colors / helpers for the Android app."""

PRIMARY = "#0B3D91"
PRIMARY_DARK = "#082C6B"
ACCENT = "#F2A900"
BG = "#F4F6F9"
CARD_BG = "#FFFFFF"
SUCCESS = "#1E8E3E"
DANGER = "#D93025"
WARNING = "#E37400"
TEXT_MUTED = "#6B7280"


def currency(amount):
    try:
        amount = float(amount)
    except (TypeError, ValueError):
        amount = 0
    return f"Rs. {amount:,.0f}"


def hex_to_rgba(hex_color, alpha=1):
    hex_color = hex_color.lstrip("#")
    r = int(hex_color[0:2], 16) / 255
    g = int(hex_color[2:4], 16) / 255
    b = int(hex_color[4:6], 16) / 255
    return [r, g, b, alpha]
