[app]

title = Chand Electronics
package.name = chandelectronics
package.domain = com.chandelectronics

source.dir = .
source.include_exts = py,png,jpg,kv,atlas,db

version = 1.0

requirements = python3,kivy==2.3.1,kivymd==1.2.0,sqlite3,pillow

orientation = portrait
fullscreen = 0

icon.filename = %(source.dir)s/icon.png

# Android permissions - writing the SQLite database to app storage
android.permissions = INTERNET

android.api = 34
android.minapi = 23
android.ndk = 25b
android.accept_sdk_license = True
android.archs = arm64-v8a, armeabi-v7a

# KivyMD ships its own fonts/images which need to be included
android.add_src =

[buildozer]
log_level = 2
warn_on_root = 1
